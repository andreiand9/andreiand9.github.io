# Mașina ta, grija noastră

Acesta este un site simplu creat pentru a promova un serviciu asemănător cu Uber,
unde un șofer vine și îți conduce mașina acasă dacă ai consumat alcool.

## Cum să-l publici pe GitHub Pages

1. Intră pe https://github.com și loghează-te în contul tău.
2. Creează un repository nou cu numele exact: `andreiand9.github.io`
3. Încarcă acest fișier `index.html` în acel repository.
4. GitHub va publica automat site-ul la adresa: https://andreiand9.github.io

Succes!
